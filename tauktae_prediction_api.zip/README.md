# 🌪️ Tauktae Cyclone Prediction API

A Flask API for predicting cyclone wind speed, intensity category, and risk level.

## 🚀 Setup Instructions

### 1️⃣ Install Dependencies
```bash
pip install -r requirements.txt
```

### 2️⃣ Run Flask App Locally
```bash
python app.py
```

Or use Docker:

```bash
docker build -t tauktae-prediction-api .
docker run -d -p 5000:5000 tauktae-prediction-api
```

### 3️⃣ Example API Request
```bash
curl -X POST http://localhost:5000/predict \
-H "Content-Type: application/json" \
-d '{"Latitude":15.5,"Longitude":72.0,"Pressure":980,"Temperature":30,"Humidity":85,"Hour":12,"Day":17,"WindSpeed_lag":55,"Pressure_lag":985,"TempHumidityIndex":25.5}'
```

## ✅ GitHub Setup Steps

1. Create new repo on GitHub: https://github.com/new
2. Clone repo locally:
   ```bash
   git clone https://github.com/your-username/tauktae-prediction-api.git
   cd tauktae-prediction-api
   ```
3. Copy all files (app.py, model.pkl, requirements.txt, Dockerfile, README.md)
4. Commit & push:
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```